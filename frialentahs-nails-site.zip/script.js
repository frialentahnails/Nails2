document.querySelector("form").addEventListener("submit", function(e) {
    alert("Thank you for booking! We will contact you shortly.");
});
